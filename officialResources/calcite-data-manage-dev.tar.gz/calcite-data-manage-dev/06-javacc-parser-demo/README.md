
# JavaCC demo运行

先运行javacc插件生成Java类。

然后运行示例 `TestParser`

